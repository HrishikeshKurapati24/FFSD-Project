const { CampaignInfluencers, CampaignInfo } = require('../../models/CampaignMongo');
const { BrandInfo } = require('../../models/BrandMongo');
const mongoose = require('mongoose');

class collaborationMetricsService {
    static async getActiveCollaborationsCount(influencerId) {
        try {
            const count = await CampaignInfluencers.countDocuments({
                influencer_id: new mongoose.Types.ObjectId(influencerId),
                status: 'active'
            });
            return count;
        } catch (error) {
            console.error('Error in getActiveCollaborationsCount:', error);
            throw error;
        }
    }

    static async getCompletionPercentage(influencerId) {
        try {
            const result = await CampaignInfluencers.aggregate([
                { $match: { influencer_id: new mongoose.Types.ObjectId(influencerId), status: 'active' } },
                { $group: { _id: null, avg_progress: { $avg: '$progress' } } }
            ]);
            return result[0]?.avg_progress || 0;
        } catch (error) {
            console.error('Error in getCompletionPercentage:', error);
            throw error;
        }
    }

    static async getNearingCompletionCount(influencerId) {
        try {
            const count = await CampaignInfluencers.countDocuments({
                influencer_id: new mongoose.Types.ObjectId(influencerId),
                status: 'active',
                progress: { $gte: 75 }
            });
            return count;
        } catch (error) {
            console.error('Error in getNearingCompletionCount:', error);
            throw error;
        }
    }

    static async getMonthlyEarnings(influencerId) {
        try {
            const CampaignPayments = mongoose.model('CampaignPayments');
            const now = new Date();
            const yearMonth = now.toISOString().slice(0, 7); // YYYY-MM

            const result = await CampaignPayments.aggregate([
                {
                    $match: {
                        influencer_id: new mongoose.Types.ObjectId(influencerId),
                        status: 'completed',
                        payment_date: {
                            $gte: new Date(yearMonth + '-01'),
                            $lt: new Date(yearMonth + '-31')
                        }
                    }
                },
                {
                    $group: {
                        _id: null,
                        total_earnings: { $sum: '$amount' }
                    }
                }
            ]);
            return result[0]?.total_earnings || 0;
        } catch (error) {
            console.error('Error in getMonthlyEarnings:', error);
            throw error;
        }
    }

    static async getEarningsChange(influencerId) {
        try {
            const CampaignPayments = mongoose.model('CampaignPayments');
            const now = new Date();
            const currentYearMonth = now.toISOString().slice(0, 7);
            const previousMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
            const previousYearMonth = previousMonthDate.toISOString().slice(0, 7);

            const result = await CampaignPayments.aggregate([
                {
                    $match: {
                        influencer_id: new mongoose.Types.ObjectId(influencerId),
                        status: 'completed',
                        payment_date: {
                            $gte: new Date(previousYearMonth + '-01'),
                            $lt: new Date(currentYearMonth + '-01')
                        }
                    }
                },
                {
                    $group: {
                        _id: '$payment_date',
                        amount: { $sum: '$amount' }
                    }
                }
            ]);

            let currentMonthTotal = 0;
            let previousMonthTotal = 0;
            result.forEach(doc => {
                const month = doc._id.toISOString().slice(0, 7);
                if (month === currentYearMonth) currentMonthTotal += doc.amount;
                else if (month === previousYearMonth) previousMonthTotal += doc.amount;
            });

            if (previousMonthTotal === 0) return 100;
            return ((currentMonthTotal - previousMonthTotal) / previousMonthTotal) * 100;
        } catch (error) {
            console.error('Error in getEarningsChange:', error);
            throw error;
        }
    }

    static async getUpcomingDeadlines(influencerId) {
        try {
            const now = new Date();
            const collaborations = await CampaignInfluencers.find({
                influencer_id: new mongoose.Types.ObjectId(influencerId),
                status: 'active',
                deadline: { $gt: now }
            })
                .populate('campaign_id', 'title')
                .populate({
                    path: 'campaign_id',
                    populate: {
                        path: 'brand_id',
                        model: 'BrandInfo',
                        select: 'brandName logoUrl'
                    }
                })
                .sort({ deadline: 1 })
                .limit(5)
                .lean();

            return collaborations.map(c => ({
                id: c._id,
                title: c.campaign_id?.title || '',
                deadline: c.deadline,
                brand_name: c.campaign_id?.brand_id?.brandName || '',
                brand_logo: c.campaign_id?.brand_id?.logoUrl || ''
            }));
        } catch (error) {
            console.error('Error in getUpcomingDeadlines:', error);
            return [];
        }
    }

    static async getPerformanceMetrics(influencerId) {
        try {
            const CampaignMetrics = mongoose.model('CampaignMetrics');
            const result = await CampaignMetrics.aggregate([
                {
                    $lookup: {
                        from: 'campaigninfos',
                        localField: 'campaign_id',
                        foreignField: '_id',
                        as: 'campaign'
                    }
                },
                { $unwind: '$campaign' },
                {
                    $match: {
                        'campaign.influencer_id': new mongoose.Types.ObjectId(influencerId)
                    }
                },
                {
                    $group: {
                        _id: null,
                        avg_engagement_rate: { $avg: '$engagement_rate' },
                        avg_reach: { $avg: '$reach' },
                        avg_conversion_rate: { $avg: '$conversion_rate' },
                        avg_timeliness: { $avg: '$timeliness_score' }
                    }
                }
            ]);

            if (!result[0]) {
                return {
                    engagementRate: 0,
                    reach: 0,
                    conversionRate: 0,
                    contentQuality: 0,
                    timeliness: 0
                };
            }

            return {
                engagementRate: result[0].avg_engagement_rate || 0,
                reach: result[0].avg_reach || 0,
                conversionRate: result[0].avg_conversion_rate || 0,
                contentQuality: result[0].avg_content_quality || 0,
                timeliness: result[0].avg_timeliness || 0
            };
        } catch (error) {
            console.error('Error in getPerformanceMetrics:', error);
            throw error;
        }
    }

    static async getEarningsBySource(influencerId) {
        try {
            const CampaignPayments = mongoose.model('CampaignPayments');
            const result = await CampaignPayments.aggregate([
                {
                    $match: {
                        influencer_id: new mongoose.Types.ObjectId(influencerId),
                        status: 'completed'
                    }
                },
                {
                    $lookup: {
                        from: 'campaigninfos',
                        localField: 'campaign_id',
                        foreignField: '_id',
                        as: 'campaign'
                    }
                },
                { $unwind: '$campaign' },
                {
                    $lookup: {
                        from: 'brandinfos',
                        localField: 'campaign.brand_id',
                        foreignField: '_id',
                        as: 'brand'
                    }
                },
                { $unwind: '$brand' },
                {
                    $group: {
                        _id: '$brand.brandName',
                        total_earnings: { $sum: '$amount' }
                    }
                },
                {
                    $sort: { total_earnings: -1 }
                }
            ]);

            return result.map(r => ({
                brand_name: r._id,
                total_earnings: r.total_earnings
            }));
        } catch (error) {
            console.error('Error in getEarningsBySource:', error);
            throw error;
        }
    }

    static computeProgressFromDeliverables(deliverables) {
        if (!Array.isArray(deliverables) || deliverables.length === 0) return 0;

        const total = deliverables.length;
        const completed = deliverables.filter(d =>
            d.status === 'approved' || d.status === 'completed' || d.completed === true
        ).length;

        if (total === 0) return 0;
        return Math.round((completed / total) * 100);
    }

    static async updateCampaignMetrics(campaignId) {
        try {
            const activeInfluencers = await CampaignInfluencers.find({
                campaign_id: campaignId,
                status: 'active'
            })
                .populate({ path: 'influencer_id', select: 'totalFollowers', model: 'InfluencerAnalytics', options: { lean: true } })
                .lean();

            if (activeInfluencers.length === 0) return;

            const influencerIds = activeInfluencers.map(ai => ai.influencer_id?._id || ai.influencer_id);
            const InfluencerAnalytics = mongoose.model('InfluencerAnalytics');
            const analytics = await InfluencerAnalytics.find({ influencerId: { $in: influencerIds } })
                .select('influencerId totalFollowers')
                .lean();
            const followersMap = new Map(analytics.map(a => [a.influencerId.toString(), a.totalFollowers || 0]));

            let weightedSum = 0;
            let totalFollowers = 0;
            activeInfluencers.forEach(ai => {
                const infId = (ai.influencer_id?._id || ai.influencer_id || '').toString();
                const followers = followersMap.get(infId) || 0;
                const prog = Math.max(0, Math.min(100, ai.progress || 0));
                weightedSum += prog * followers;
                totalFollowers += followers;
            });

            const overallProgress = totalFollowers > 0 ? Math.round((weightedSum / totalFollowers)) : Math.round((activeInfluencers.reduce((s, ai) => s + (ai.progress || 0), 0) / Math.max(1, activeInfluencers.length)));

            const campaign = await CampaignInfo.findById(campaignId).select('brand_id');
            if (campaign) {
                const CampaignMetrics = mongoose.model('CampaignMetrics');
                await Promise.all([
                    CampaignInfo.updateOne(
                        { _id: campaignId },
                        { $set: { 'metrics.overall_progress': overallProgress } }
                    ),
                    CampaignMetrics.findOneAndUpdate(
                        { campaign_id: campaignId, brand_id: campaign.brand_id },
                        { $set: { overall_progress: overallProgress } },
                        { upsert: true, new: true }
                    )
                ]);
            }


        } catch (error) {
            console.error('Error in updateCampaignMetrics:', error);
        }
    }
}

module.exports = collaborationMetricsService;
